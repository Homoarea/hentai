"""
██╗  ██╗███████╗███╗   ██╗████████╗ █████╗ ██╗
██║  ██║██╔════╝████╗  ██║╚══██╔══╝██╔══██╗██║
███████║█████╗  ██╔██╗ ██║   ██║   ███████║██║
██╔══██║██╔══╝  ██║╚██╗██║   ██║   ██╔══██║██║
██║  ██║███████╗██║ ╚████║   ██║   ██║  ██║██║
╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚═╝
"""
__title__="ehentai"
__description__="Python for viewing e-hentai"
__version__="0.1"
__url__="https://github.com/Homoarea/hentai"
__build__=0x3f3f3f
__author__="Homoarea"
__author_email__="homoarea114@gmail.com"
__license__="GNU GPLv3"
__copyright__="Copyright Homoarea"
